#include <pgmspace.h>

// Device Private Key                                               
static const char AWSClientPrivateKey[] PROGMEM = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
// Please download the device private key from AWS IoT Core when you create the thing and paste it here//
-----END RSA PRIVATE KEY-----
)EOF";
