#include <pgmspace.h>

// Device Certificate                                              
static const char AWSClientCertificate[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
// Please download the device certificate from AWS IoT Core when you create the thing and paste it here//
-----END CERTIFICATE-----
)EOF";
