Serial.println("Enviando pedido para configurar IR");
delay(100);
    // Envia os 4 bytes binários CONFIG LED 0b00000000

    byte dataToSend_ir[4] = {0b00000011, 0b00000010, 0b00110000, 000000000};
    Serial.write(dataToSend_ir,4);
    Serial.println("Enviado");
    delay(3000);
    
    if (Serial.available() >= 27) {
        // Lê 27 bytes da porta serial software
        Serial.readBytes(data_receive, 27);
        
        // Imprime os 27 bytes recebidos no Serial Monitor
        //Serial.println("Bytes recebidos:");
        //for (int i = 0; i < bytesRead; i++) {
        //Serial.print(data_receive[i], HEX);
        //Serial.print(" ");
        //}
    }
   
    
    // Adicione um pequeno atraso para evitar múltiplas leituras seguidas
    //delay(1000);
    i2c1_ir = (data_receive[3] << 16) | (data_receive[2] << 8) | data_receive[1];
    i2c1_green = (data_receive[6] << 16) | (data_receive[5] << 8) | data_receive[4];
    i2c1_red = (data_receive[9] << 16) | (data_receive[8] << 8) | data_receive[7];
    i2c1_blue = (data_receive[12] << 16) | (data_receive[11] << 8) | data_receive[10];

    i2c2_ir = (data_receive[15] << 16) | (data_receive[14] << 8) | data_receive[13];
    i2c2_green = (data_receive[18] << 16) | (data_receive[17] << 8) | data_receive[16];
    i2c2_red = (data_receive[21] << 16) | (data_receive[20] << 8) | data_receive[19];
    i2c2_blue = (data_receive[24] << 16) | (data_receive[23] << 8) | data_receive[22];
    
print_value_read(i2c1_red, i2c1_green, i2c1_blue, i2c1_ir, i2c2_red, i2c2_green, i2c2_blue, i2c2_ir);



// Enviando dados na config IR
publish_value_to_mqtt(ir_turb_i2c1_red, i2c1_red);
delay(100);
publish_value_to_mqtt(ir_turb_i2c1_green, i2c1_green);
delay(100);
publish_value_to_mqtt(ir_turb_i2c1_blue, i2c1_blue);
delay(100);
publish_value_to_mqtt(ir_turb_i2c1_ir, i2c1_ir);
delay(100);

publish_value_to_mqtt(ir_nef_i2c2_red, i2c2_red);
delay(100);
publish_value_to_mqtt(ir_nef_i2c2_green, i2c2_green);
delay(100);
publish_value_to_mqtt(ir_nef_i2c2_blue, i2c2_blue);
delay(100);
publish_value_to_mqtt(ir_nef_i2c2_ir, i2c2_ir);
delay(100);


delay(8000);    
mqtt.loop();